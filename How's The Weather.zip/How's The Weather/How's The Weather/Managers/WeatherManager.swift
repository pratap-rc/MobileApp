//
//  WeatherManager.swift
//  How's The Weather
//
//  Created by pratap.roychowdhury on 31/03/22.
//

import Foundation
import CoreLocation

class WeatherManager {
	
	func getCurrentWeather(latitude: CLLocationDegrees, longitude: CLLocationDegrees) async throws -> WeatherResponse {
		let apiKey = "c0ed3e1d40a20a4dfe04f9e28db1b57d"
		guard let url = URL(string: "https://api.openweathermap.org/data/2.5/weather?lat=\(latitude)&lon=\(longitude)&appid=\(apiKey)&units=metric") else {
			fatalError("Invalid URL")
		}
		let urlRequest = URLRequest(url: url)
		
		let (data,response) = try await URLSession.shared.data(for: urlRequest)
		
		guard (response as? HTTPURLResponse)?.statusCode == 200 else {
			fatalError("invalid API response")
		}
		
		let decodedResponse = try JSONDecoder().decode(WeatherResponse.self, from: data)
		return decodedResponse
	}
	
}

// "https://api.openweathermap.org/data/2.5/weather?lat=22.572645&lon=88.363892&appid=c0ed3e1d40a20a4dfe04f9e28db1b57d&units=metric"

