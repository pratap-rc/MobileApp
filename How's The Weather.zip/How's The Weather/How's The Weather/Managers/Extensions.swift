//
//  Extensions.swift
//  How's The Weather
//
//  Created by pratap.roychowdhury on 31/03/22.
//

import Foundation

extension Double {
	func round() -> String {
		return String(format: "%.0f", self)
	}
}
