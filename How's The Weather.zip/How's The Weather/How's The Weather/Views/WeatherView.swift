//
//  WeatherView.swift
//  How's The Weather
//
//  Created by pratap.roychowdhury on 31/03/22.
//

import SwiftUI

struct WeatherView: View {
	var weather: WeatherResponse
    var body: some View {
		ZStack(alignment: .leading) {
			VStack {
				VStack(alignment: .leading, spacing: 15) {
					Text(weather.name)
						.bold().font(.title)
					Text("Today - \(Date().formatted(.dateTime.month().day().hour().minute()))")
						.fontWeight(.heavy)
				}
				.frame(maxWidth: .infinity, alignment: .leading)
				
				Spacer()
				
				VStack {
					HStack {
						VStack(spacing: 20) {
							let condition = weather.weather[0].main
							let iconName = determineWeatherIcon(condition: condition)
							Image(systemName: iconName)
								.font(.system(size: 40))
							
							Text(weather.weather[0].main)
								.fontWeight(.heavy)
						}
						.frame(width: 150, alignment: .leading)
						
						Spacer()
						
						Text(weather.main.feelsLike.round()+"°")
							.font(.system(size: 100))
							.bold()
							.padding()
					}
					
					Spacer()
				}
				.frame(maxWidth: .infinity)
				
			}
			.padding()
			.frame(maxWidth: .infinity, alignment: .leading)
			
			VStack {
				Spacer()
				
				VStack (alignment: .leading, spacing: 20) {
					Text("Weather Now")
						.bold()
						.padding()
					HStack {
						WeatherInfo(logo: "thermometer", name: "Min Temp", value: weather.main.minTemp.round() + "°")
						Spacer()
						WeatherInfo(logo: "thermometer", name: "Max Temp", value: weather.main.maxTemp.round() + "°")
					}
					HStack {
						WeatherInfo(logo: "wind", name: "Wind Speed", value: weather.wind.speed.round() + " m/s")
						Spacer()
						WeatherInfo(logo: "humidity", name: "Humidity", value: weather.main.humidity.round() + " %")
					}
					
				}
				.frame(maxWidth: .infinity, alignment: .leading)
				.padding()
				.padding(.bottom, 20)
				.foregroundColor(Color(hue: 0.635, saturation: 0.917, brightness: 0.288))
				.background(.white)
				.cornerRadius(20)
				
			}
			
		}
		.edgesIgnoringSafeArea(.bottom)
		.background(Color(hue: 0.635, saturation: 0.917, brightness: 0.288))
		.preferredColorScheme(.dark)
    }
	
	func determineWeatherIcon(condition: String) -> String {
		let iconDict : [String:String] =  ["Clouds":"cloud","Clear.day":"sun.max","Clear.night":"moon.stars","Rain":"cloud.rain","Snow" :"cloud.snow","Extreme":"tropicalstorm","Haze":"smoke.fill"]
		let time = determineTimeOfTheDay()
		let key = condition == "Clear" ? condition + "." + time : condition
		guard let icon = iconDict[key] else {
			return ""
		}
		return icon
	}
	
	func determineTimeOfTheDay() -> String {
		let hour = Calendar.current.component(.hour, from: Date())

		switch hour {
		case 6..<18 : return "day"
		default: return "night"
		}
	}
}

struct WeatherView_Previews: PreviewProvider {
    static var previews: some View {
		WeatherView(weather: PreviewData.shared.load("weatherDummy.json"))
    }
}
