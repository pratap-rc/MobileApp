//
//  WelcomeView.swift
//  How's The Weather
//
//  Created by pratap.roychowdhury on 30/03/22.
//

import SwiftUI
import CoreLocationUI

struct WelcomeView: View {
	@EnvironmentObject var locationManager: LocationManager
	var locationText = "Please Share Your Current Location to Check the Weather in your Area"
	
    var body: some View {
		VStack {
			VStack {
				Text("Welcome To Your Weather App")
					.font(.title).fontWeight(.bold)
				Text(locationText).padding()
				
			}
			.multilineTextAlignment(.center).padding()
			
			LocationButton(.shareCurrentLocation) {
				locationManager.requestLocation()
			}
			.cornerRadius(30)
			.symbolVariant(.fill)
			.foregroundColor(.white)
			
		}.frame( maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
