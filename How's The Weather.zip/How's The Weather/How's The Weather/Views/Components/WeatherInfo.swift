//
//  WeatherInfo.swift
//  How's The Weather
//
//  Created by pratap.roychowdhury on 31/03/22.
//

import SwiftUI

struct WeatherInfo: View {
	var logo: String
	var name: String
	var value: String
	var body: some View {
		HStack(spacing: 20) {
			Image(systemName: logo)
				.font(.title2)
				.frame(width: 30, height: 30)
				.padding()
				.background(Color(hue: 0.635, saturation: 0.047, brightness: 0.946))
				.cornerRadius(50)
			
			VStack(alignment: .leading, spacing: 8) {
				Text(name)
					.font(.caption)
				
				Text(value)
					.bold()
					.font(.title)
			}
		}
    }
}

struct WeatherInfo_Previews: PreviewProvider {
    static var previews: some View {
		WeatherInfo(logo: "humidity", name: "Feels Like", value: "8°")
    }
}
