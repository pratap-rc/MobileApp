//
//  ContentView.swift
//  How's The Weather
//
//  Created by pratap.roychowdhury on 29/03/22.
//

import SwiftUI

struct ContentView: View {
	@StateObject var locationManager = LocationManager()
	var weatherManager = WeatherManager()
	@State var weather: WeatherResponse?
    var body: some View {
		VStack {
			if let location = locationManager.location {
				if let weather = weather {
					WeatherView(weather: weather)
				} else {
					LoadingView()
						.task {
							do {
								weather = try await weatherManager.getCurrentWeather(latitude: location.latitude, longitude: location.longitude)
							} catch {
								print("error getting weather: \(Error.self)")
							}
						}
				}
			} else if (locationManager.isLoading) {
				LoadingView()
			} else {
				WelcomeView()
					.environmentObject(locationManager)
			}
		}.background(Color(hue: 0.635, saturation: 0.917, brightness: 0.288)).preferredColorScheme(.dark)
			
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
