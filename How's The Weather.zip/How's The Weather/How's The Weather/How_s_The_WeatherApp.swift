//
//  How_s_The_WeatherApp.swift
//  How's The Weather
//
//  Created by pratap.roychowdhury on 29/03/22.
//

import SwiftUI

@main
struct How_s_The_WeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
