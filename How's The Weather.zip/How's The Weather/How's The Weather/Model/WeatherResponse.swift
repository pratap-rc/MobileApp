//
//  WeatherResponse.swift
//  How's The Weather
//
//  Created by pratap.roychowdhury on 31/03/22.
//

import Foundation

struct WeatherResponse: Decodable {
	
	var coord: Coordinates
	var weather: [Weather]
	var main: MainResponse
	var wind: WindResponse
	var name: String
	
	struct Coordinates: Decodable {
		var lon : Double
		var lat : Double
	}
	
	struct Weather: Decodable {
		var id: Double
		var main: String
		var description: String
		var icon: String
	}
	
	struct MainResponse: Decodable {
		var temp: Double
		var feels_like: Double
		var temp_min: Double
		var temp_max: Double
		var pressure: Double
		var humidity: Double
	}
	
	struct WindResponse: Decodable {
		var speed: Double
		var deg: Double
	}
	
	
}

extension WeatherResponse.MainResponse {
	var feelsLike: Double {return feels_like}
	var minTemp: Double {return temp_min}
	var maxTemp: Double {return temp_max}
}
