//
//  ControlView.swift
//  MyVideoPlayer
//
//  Created by pratap.roychowdhury on 28/04/22.
//

import UIKit

protocol ControlDelegate: AnyObject {
	func playButtonTapped(shouldPlay: Bool)
	func volumeButtonTapped(shouldMute: Bool, volumeValue: Float)
	func setVolume(volume: Float)
	func seekToTime(time: Float)
}

class ControlView: UIView {
	
	weak var controlDelegate: ControlDelegate!
	
	private var playButton: UIButton!
	private var volumeButton: UIButton!
	private var volumeSlider: UISlider!
	private var seeker: UISlider!
	private var timeLabel: UILabel!
	
	
	var isVideoPlaying = false
	var isMute = false
	var volume: Float = 0.5 // default volume on start
	
	override init(frame: CGRect) {
		super.init(frame: frame)
		alpha = 0.8
		createControls()
	}
	
	required init?(coder: NSCoder) {
		fatalError("init(coder:) has not been implemented")
	}
	
	private func createControls() {
		
		// volume slider
		
		volumeSlider = UISlider()
		volumeSlider.addTarget(self, action: #selector(sliderValueChanged), for: .valueChanged)
		volumeSlider.translatesAutoresizingMaskIntoConstraints = false
		addSubview(volumeSlider)
		volumeSlider.value = volume
		
		// Play pause button
		
		playButton = UIButton(type: .custom)
		playButton.tintColor = .systemBlue
		let config = UIImage.SymbolConfiguration(textStyle: .title2)
		playButton.setImage(UIImage(systemName: "play.fill", withConfiguration: config)?.withTintColor(.systemGray3, renderingMode: .alwaysTemplate), for: .normal)
		playButton.addTarget(self, action: #selector(playButtonTapped), for: .touchUpInside)
		playButton.translatesAutoresizingMaskIntoConstraints = false
		addSubview(playButton)
		
		// volume button
		volumeButton = UIButton(type: .custom)
		volumeButton.tintColor = .systemBlue
		volumeButton.setImage(UIImage(systemName: "speaker.wave.2.circle.fill", withConfiguration: config)?.withTintColor(.systemGray3, renderingMode: .alwaysTemplate), for: .normal)
		volumeButton.addTarget(self, action: #selector(volumeButtonTapped), for: .touchUpInside)
		volumeButton.translatesAutoresizingMaskIntoConstraints = false
		addSubview(volumeButton)
		
		// timestamp label
		timeLabel = UILabel()
		timeLabel.adjustsFontSizeToFitWidth = true
		timeLabel.font = UIFont.preferredFont(forTextStyle: .body)
		timeLabel.textColor = .label
		timeLabel.translatesAutoresizingMaskIntoConstraints = false
		addSubview(timeLabel)
		
		//seeker. disbaled on start will be enabled when video is available.
		seeker = UISlider()
		seeker.isUserInteractionEnabled = false
		seeker.translatesAutoresizingMaskIntoConstraints = false
		seeker.addTarget(self, action: #selector(seekerValueChanged), for: .valueChanged)
		addSubview(seeker)
		
		NSLayoutConstraint.activate([
			seeker.topAnchor.constraint(equalTo: topAnchor, constant: 16),
			seeker.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
			
			playButton.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
			playButton.topAnchor.constraint(equalTo: seeker.bottomAnchor, constant: 16),
			playButton.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -16),
			
			volumeButton.leadingAnchor.constraint(equalTo: playButton.trailingAnchor, constant: 16),
			volumeButton.topAnchor.constraint(equalTo: playButton.topAnchor),
			volumeButton.bottomAnchor.constraint(equalTo: playButton.bottomAnchor),
			
			volumeSlider.leadingAnchor.constraint(equalTo: volumeButton.trailingAnchor, constant: 16),
			volumeSlider.widthAnchor.constraint(equalToConstant: 200),
			volumeSlider.bottomAnchor.constraint(equalTo: playButton.bottomAnchor),
			volumeSlider.topAnchor.constraint(equalTo: playButton.topAnchor),
			
			timeLabel.topAnchor.constraint(equalTo: seeker.topAnchor),
			timeLabel.bottomAnchor.constraint(equalTo: seeker.bottomAnchor),
			timeLabel.leadingAnchor.constraint(equalTo: seeker.trailingAnchor, constant: 8),
			timeLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8)
		])
	}
	
	func setTimeLabelValue(totalTime: String, currentTime: String) {
		timeLabel.text = "\(currentTime)/\(totalTime)"
		seeker.isUserInteractionEnabled = true // enabling seeker on available of video
	}
	
	func setSeekerValues(min: Float, max: Float, current: Float) {
		if max == 0.0 {
			seeker.isUserInteractionEnabled = false
		} else {
			seeker.isUserInteractionEnabled = true
		}
		seeker.maximumValue = max
		seeker.minimumValue = min
		seeker.value = current
	}
	
	@objc private func playButtonTapped() {
		guard let delegate = controlDelegate  else {return}
		if isVideoPlaying {
			isVideoPlaying = false
			setImageForButton(systemImageName: "play.fill", for: playButton)
		} else {
			isVideoPlaying = true
			setImageForButton(systemImageName: "pause.fill", for: playButton)
		}
		delegate.playButtonTapped(shouldPlay: isVideoPlaying)
	}
	
	@objc private func volumeButtonTapped() {
		guard let delegate = controlDelegate  else {return}
		if isMute {
			isMute = false
			volumeSlider.value = volume == 0.0 ? 0.5 : volume
			setImageForButton(systemImageName: "speaker.wave.2.circle.fill", for: volumeButton)
		} else {
			isMute = true
			volume = volumeSlider.value
			volumeSlider.value = 0.0
			setImageForButton(systemImageName: "speaker.slash.fill", for: volumeButton)
		}
		delegate.volumeButtonTapped(shouldMute: isMute, volumeValue: volume )
	}
	
	@objc private func sliderValueChanged() {
		let volumeOfSlider = volumeSlider.value
		guard let delegate = controlDelegate  else {return}
		if volumeOfSlider == 0.0 {
			isMute = true
			volume = 0.0
			setImageForButton(systemImageName: "speaker.slash.fill", for: volumeButton)
		} else if isMute {
			isMute = false
			setImageForButton(systemImageName: "speaker.wave.2.circle.fill", for: volumeButton)
		}
		delegate.setVolume(volume: volumeOfSlider)
	}
	
	@objc private func seekerValueChanged() {
		guard let delegate = controlDelegate  else {return}
		delegate.seekToTime(time: seeker.value)
	}
	
	private func setImageForButton(systemImageName: String, for button: UIButton) {
		let config = UIImage.SymbolConfiguration(textStyle: .title2)
		button.setImage(UIImage(systemName: systemImageName, withConfiguration: config)?.withTintColor(.systemGray3, renderingMode: .alwaysTemplate), for: .normal)
	}

}
