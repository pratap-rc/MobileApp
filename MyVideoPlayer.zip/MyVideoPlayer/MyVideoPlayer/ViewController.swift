//
//  ViewController.swift
//  MyVideoPlayer
//
//  Created by pratap.roychowdhury on 27/04/22.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
	
	private var player: AVPlayer!
	private var playerLayer: AVPlayerLayer!
	private var baseView: UIView!
	private var controlView: ControlView! // This is a Custom View component that holds the play, mute and other controls.
	
	private let url = URL(string: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4")
	private var currentTime = 0.0	// current timestamp of the video tied up with observer
	private var totalDuration = 0.0 // total duration of the video
	
	override func viewDidLoad() {
		super.viewDidLoad()
		createLayout() // Creates the layout and set constraints.
		createPlayer() // creates the plaer and player Layer
		addTimeObserver() // Adds a periodic observer to the player for seeker to move
	}
	
	override func viewDidLayoutSubviews() {
		super.viewDidLayoutSubviews()
		playerLayer.frame = baseView.bounds
	}
	
	private func addTimeObserver() {
		let interval = CMTime(seconds: 0.5, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
		player.addPeriodicTimeObserver(forInterval: interval, queue: DispatchQueue.main) { [weak self] time in
			guard let safeSelf = self, let currentItem = safeSelf.player.currentItem else {return}
			// updates the seeker value with the time
			safeSelf.controlView.setSeekerValues(min: 0.0,
												 max: Float(currentItem.duration.seconds),
												 current: Float(currentItem.currentTime().seconds))
			//updates the timelabel value beside seeker
			safeSelf.controlView.setTimeLabelValue(totalTime: safeSelf.getTimeString(safeSelf.totalDuration),
												   currentTime: safeSelf.getTimeString(currentItem.currentTime().seconds))
		}
	}
	
	private func createPlayer() {
		guard let url = url else { return }
		player = AVPlayer(url: url)
		// adding observer to get the total duration
		player.currentItem?.addObserver(self, forKeyPath: "duration", options: [.new, .initial], context: nil)
		playerLayer = AVPlayerLayer(player: player)
		playerLayer.videoGravity = .resize
		baseView.layer.addSublayer(playerLayer)
	}
	
	private func createLayout() {
		baseView = UIView()
		baseView.backgroundColor = .black
		
		view.addSubview(baseView)
		baseView.translatesAutoresizingMaskIntoConstraints = false
		
		controlView = ControlView()
		controlView.controlDelegate = self
		controlView.translatesAutoresizingMaskIntoConstraints = false
		view.addSubview(controlView)
		
		NSLayoutConstraint.activate([
			baseView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
			baseView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
			baseView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
			baseView.heightAnchor.constraint(equalTo: baseView.widthAnchor, multiplier: 9.0/16.0),
			
			controlView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -16),
			controlView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
			controlView.trailingAnchor.constraint(greaterThanOrEqualTo: view.trailingAnchor, constant: 0)
		])
		
	}
	
	// updating the total duration based on observed value.
	override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
		if keyPath == "duration", let duration = player.currentItem?.duration.seconds, duration > 0.0 {
			totalDuration = duration
			controlView.setTimeLabelValue(totalTime: String(getTimeString(totalDuration)), currentTime: "0:0")
		}
	}
	
	
	// format the time in seconds to readble time format.
	private func getTimeString(_ seconds: Double) -> String {
		let hours = Int(seconds/3600)
		let minute = Int(seconds/60) % 60
		let second = Int(seconds.truncatingRemainder(dividingBy: 60))
		
		if hours > 0 {
			return String(format: "%i:%02i:%02i", arguments: [hours, minute, second])
		} else {
			return String(format: "%02i:%02i", arguments: [minute, second])
		}
	}

}

// Conformance to Control Delegate Protocol so that action can be taken on events.
extension ViewController: ControlDelegate {
	func seekToTime(time: Float) {
		player.seek(to: CMTimeMake(value: Int64(time*1000), timescale: 1000))
	}
	
	func setVolume(volume: Float) {
		player.volume = volume
	}
	
	
	func volumeButtonTapped(shouldMute: Bool, volumeValue: Float) {
		if shouldMute {
			player.volume = 0.0
		} else {
			player.volume = volumeValue
		}
	}
	
	func playButtonTapped(shouldPlay: Bool) {
		if shouldPlay {
			player.play()
		} else {
			player.pause()
		}
	}
	
}








